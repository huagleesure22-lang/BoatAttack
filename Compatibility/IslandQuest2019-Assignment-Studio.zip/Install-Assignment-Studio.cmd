@echo off
setlocal EnableExtensions DisableDelayedExpansion
title IslandQuest - Assignment Studio
echo Close Unity before continuing. Run normally; no administrator rights needed.
echo Adds a separate UV-textured, rigged asset studio for Unity 2019.3.0f6.
echo.
set "patchPath=%~dp0"
if not exist "%patchPath%Assets\IslandQuest2019\Portfolio\Editor\PortfolioBuilder.cs" goto missing
set "targetPath=D:\BoatAttack-2019-From2020-28614-30466"
if exist "%targetPath%\Assets\IslandQuest2019\Runtime\QuestInput.cs" goto ready
echo Paste your Unity project folder, without surrounding quotes.
set /p "targetPath=Project folder: "
:ready
if not exist "%targetPath%\Assets\IslandQuest2019\Runtime\QuestInput.cs" goto wrong
set "versionOK="
for /f "usebackq tokens=1,2" %%A in ("%targetPath%\ProjectSettings\ProjectVersion.txt") do if "%%A"=="m_EditorVersion:" if "%%B"=="2019.3.0f6" set "versionOK=1"
if not defined versionOK goto wrong
set "ISLANDQUEST_PATCH=%patchPath%"
echo Verifying files...
powershell.exe -NoProfile -Command "$ErrorActionPreference='Stop'; $root=$env:ISLANDQUEST_PATCH; $hashes=Get-Content -LiteralPath (Join-Path $root 'SHA256.json') -Raw | ConvertFrom-Json; foreach($entry in $hashes.PSObject.Properties) { if ((Get-FileHash -LiteralPath (Join-Path $root $entry.Name) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.Value) { throw ('Checksum mismatch: '+$entry.Name) } }"
if errorlevel 1 goto failed
if not exist "%targetPath%\Assets\IslandQuest2019\Portfolio" goto install
set "backupPath=%targetPath%\PortfolioBackup-%RANDOM%-%RANDOM%"
if exist "%backupPath%" goto failed
echo Backing up the previous studio...
robocopy "%targetPath%\Assets\IslandQuest2019\Portfolio" "%backupPath%\Portfolio" /E /R:1 /W:1 /NFL /NDL /NJH /NJS
if errorlevel 8 goto failed
:install
echo Installing the separate assignment studio...
robocopy "%patchPath%Assets" "%targetPath%\Assets" /E /R:1 /W:1 /NFL /NDL /NJH /NJS
if errorlevel 8 goto failed
echo.
echo DONE - Open Unity and wait for compilation.
echo Island2019 / 6 - Build Assignment Studio
echo Island2019 / 7 - Export Assignment PNGs
echo Or press Play and click the bottom screenshot button.
echo PNGs are saved in the project's Screenshots folder.
echo This installer does not change combat code or the island scene.
pause
exit /b 0
:missing
echo ERROR - Extract ALL files from the ZIP before running this CMD.
goto stop
:wrong
echo ERROR - Select the Unity 2019.3.0f6 project with IslandQuest2019 installed.
goto stop
:failed
echo ERROR - Verification, backup or installation failed. Send this window.
:stop
pause
exit /b 1
