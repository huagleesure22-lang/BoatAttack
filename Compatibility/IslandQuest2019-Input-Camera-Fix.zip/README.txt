Unity 2019 输入与镜头修复

截图中的红色错误明确指出：脚本读取传统 UnityEngine.Input，但工程启用了新版 Input System 且禁用了旧输入。
本补丁使所有控制、截图快捷键和 R 重试按当前启用的后端读取输入。
兼容你工程的 Input System 1.0.0-preview.4，不下载或替换任何 Unity 包。

1. 停止 Play，保存场景，关闭 Unity。
2. 完整解压本 ZIP，双击 Fix-IslandQuest2019.cmd。
3. 看到 DONE 后重新打开当前 2019 工程，等待编译结束。编辑器会自动同步兼容编译符号，可能会再编译一次。
4. 点击 Island2019 → 2 - Build Island Combat Scene，重新生成战斗场景。
5. 点击 Play，再点击游戏画面。WASD 移动，鼠标转镜头，左键挥剑，E 开箱。

改变：
- 开始前、Esc 释放鼠标后或切出游戏窗口时，骷髅暂停，不会趁尚未开始时击杀主人公。
- 战斗台会避开周围地形、建筑和树冠，增加补光，去掉挡镜头的英文招牌。
- 展示场景的大字缩小，若要更新展示场景，用菜单 1 重新生成。

现有模型与场景不在安装时修改；现有 IslandQuest2019 文件夹完整备份在工程根目录 IslandQuestBackup-*。
重新生成时，旧的战斗/展示场景会先备份到 Assets/IslandQuest2019/SceneBackups。
静态 island_clean_2019 场景保留。

已检查：新输入分支不再引用旧 Input 调用；新、旧输入分支均编译通过；新版对照官方 1.0.0-preview.4 源码；开始/暂停/死亡保护和升级规则测试通过；ZIP 校验通过。
云端使用可用的 Unity 2020 托管程序集做编译检查，尚未在原生 Unity 2019 中完成 Play 测试。
