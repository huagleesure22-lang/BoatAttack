@echo off
setlocal EnableExtensions DisableDelayedExpansion
title IslandQuest2019 - Input and Camera Fix
echo Fix keyboard/mouse input and the obstructed trial camera.
echo Save your scene, then CLOSE Unity. No administrator rights needed.
echo Existing code will be backed up before the new files are installed.
echo.
set "patchPath=%~dp0"
if not exist "%patchPath%Assets\IslandQuest2019\Runtime\QuestInput.cs" goto missingPatch
set "targetPath=D:\BoatAttack-2019-From2020-28614-30466"
if exist "%targetPath%\Assets\IslandQuest2019\Editor\QuestAssetBuilder.cs" goto targetReady
echo Paste the Unity 2019 project folder, without surrounding quotes.
set /p "targetPath=Project folder: "
:targetReady
if not exist "%targetPath%\Assets\IslandQuest2019\Runtime\QuestHero.cs" goto wrongProject
set "versionOK="
for /f "usebackq tokens=1,2" %%A in ("%targetPath%\ProjectSettings\ProjectVersion.txt") do if "%%A"=="m_EditorVersion:" if "%%B"=="2019.3.0f6" set "versionOK=1"
if not defined versionOK goto wrongProject
set "backupPath=%targetPath%\IslandQuestBackup-%RANDOM%-%RANDOM%"
if exist "%backupPath%" goto collision
set "ISLANDQUEST_PATCH=%patchPath%"
echo Verifying update files...
powershell.exe -NoProfile -Command "$ErrorActionPreference='Stop'; $root=$env:ISLANDQUEST_PATCH; $hashes=Get-Content -LiteralPath (Join-Path $root 'SHA256.json') -Raw | ConvertFrom-Json; foreach($entry in $hashes.PSObject.Properties) { if ((Get-FileHash -LiteralPath (Join-Path $root $entry.Name) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.Value) { throw ('Checksum mismatch: '+$entry.Name) } }"
if errorlevel 1 goto failed
echo Backing up the current assets and code...
robocopy "%targetPath%\Assets\IslandQuest2019" "%backupPath%\IslandQuest2019" /E /R:1 /W:1 /NFL /NDL /NJH /NJS
if errorlevel 8 goto failed
echo Applying the input and camera fixes...
robocopy "%patchPath%Assets" "%targetPath%\Assets" /E /R:1 /W:1 /NFL /NDL /NJH /NJS
if errorlevel 8 goto failed
echo.
echo DONE - Update installed. Models and existing scenes were preserved.
echo Backup: "%backupPath%"
echo Reopen Unity 2019.3.0f6 and WAIT until compilation has finished.
echo Use Island2019 / 2 - Build Island Combat Scene to update the terrace.
echo Old generated scenes are backed up automatically when rebuilt.
echo Press Play, then CLICK the Game view to start. WASD moves, mouse aims.
echo Esc pauses combat. R restarts after defeat. F8 takes screenshots.
echo Use menu 1 again if you also want the improved gallery labels.
pause
exit /b 0
:missingPatch
echo ERROR - Extract the whole ZIP first. Assets must be beside this CMD.
goto stop
:wrongProject
echo ERROR - Select your Unity 2019.3.0f6 project with IslandQuest2019 installed.
goto stop
:collision
echo ERROR - Backup folder already exists. Run again to choose another name.
goto stop
:failed
echo ERROR - Verification, backup or installation failed. Send this window.
:stop
pause
exit /b 1
