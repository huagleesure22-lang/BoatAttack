潮岸遗物：原创主人公、骷髅怪、三阶长剑与升级宝箱
目标编辑器：Unity 2019.3.0f6。使用当前已经能打开的去船海岛工程。

安装步骤：
1. 在 Unity 保存场景，关闭 Unity。
2. 右键本 ZIP，全部解压。不要在压缩预览窗口里运行脚本。
3. 普通双击 Install-IslandQuest2019.cmd。
4. 默认安装到 D:\BoatAttack-2019-From2020-28614-30466。目录不同则粘贴实际工程根目录。
5. DONE 后重新打开工程，等待右下角编译结束。
6. 顶部 Island2019 → 1 - Build Assets and Gallery，生成模型预制体和展示场景。
7. 点击 Play，按 0 总览、1 主角、2 骷髅、3 武器、4 宝箱。鼠标拖动旋转，滚轮缩放。
8. F8 保存清晰截图到工程根目录 Screenshots；F1 隐藏说明。

要试玩战斗：
Island2019 → 2 - Build Island Combat Scene。该菜单另存新场景，在海岛放置战斗石台。
WASD 移动、Shift 加速、空格跳跃、鼠标转镜头、左键攻击、靠近宝箱按 E。
击败 2 / 4 只骷髅后，宝箱分别提升武器伤害至 30 / 48；初始伤害 18。
开箱恢复 30 生命；六只骷髅全部清除后完成试炼。
Esc 释放鼠标；点击画面继续。死亡后 R 重试。

原静态海岛场景保留。安装仅增加 Assets/IslandQuest2019；已有该文件夹时工具会停止，避免覆盖你的编辑。
菜单生成的可复用网格、材质、预制体位于 Assets/IslandQuest2019/Generated。
战斗版目前以石台试炼为范围；不等于全岛开放世界任务。

Preview/Assets_Overview.png 是同一批模型的真实 Blender 渲染，便于先看成品。
SourceModels/IslandQuest_OriginalAssets.blend 是可编辑建模源文件，放在 Assets 外，避免 Unity 调用外部 Blender 导入。
随包建模脚本在 Assets/IslandQuest2019/Source。

验证：模型网格、层级、Blender 渲染、升级规则测试和可用 Unity 托管 API 编译检查通过。
云端未完成 Unity 2019 本地导入及 Play 验证。若 Unity 有红色错误，请发送第一条完整 Console 错误。
作业按通知只交成品截图，截止 2026年10月18日 23:59；建议在 Unity 展示场景拍总览及资产近景。

已更新输入兼容：支持启用的新、旧输入系统。Play 后点击画面开始；Esc 或切出窗口暂停。生成器自动同步编译符号，重编译结束后再 Play。
