@echo off
setlocal EnableExtensions DisableDelayedExpansion
title Island Quest - Original 3D Assets and Third Person Combat
echo Install original hero, skeleton, swords and chest for Unity 2019.3.0f6.
echo Save your Unity scene and CLOSE Unity before continuing.
echo Run normally. No administrator rights or Git download is needed.
echo.
set "patchPath=%~dp0"
if not exist "%patchPath%Assets\IslandQuest2019\Editor\QuestAssetBuilder.cs" goto missingPatch
set "targetPath=D:\BoatAttack-2019-From2020-28614-30466"
if exist "%targetPath%\ProjectSettings\ProjectVersion.txt" goto targetReady
echo Paste the Unity 2019 project folder, without surrounding quotes.
set /p "targetPath=Project folder: "
:targetReady
if not exist "%targetPath%\Assets\scenes\island_clean_2019.unity" goto wrongProject
set "versionOK="
for /f "usebackq tokens=1,2" %%A in ("%targetPath%\ProjectSettings\ProjectVersion.txt") do if "%%A"=="m_EditorVersion:" if "%%B"=="2019.3.0f6" set "versionOK=1"
if not defined versionOK goto wrongProject
if exist "%targetPath%\Assets\IslandQuest2019" goto alreadyInstalled
set "ISLANDQUEST_PATCH=%patchPath%"
echo Verifying the patch files...
powershell.exe -NoProfile -Command "$ErrorActionPreference='Stop'; $root=$env:ISLANDQUEST_PATCH; $hashes=Get-Content -LiteralPath (Join-Path $root 'SHA256.json') -Raw | ConvertFrom-Json; foreach($entry in $hashes.PSObject.Properties) { $file=Join-Path $root $entry.Name; if ((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.Value) { throw ('Patch checksum mismatch: '+$entry.Name) } }"
if errorlevel 1 goto failed
echo Installing new assets in "%targetPath%" ...
robocopy "%patchPath%Assets" "%targetPath%\Assets" /E /R:1 /W:1 /NFL /NDL /NJH /NJS
if errorlevel 8 goto failed
echo.
echo DONE - Original digital assets and gameplay scripts are installed.
echo Reopen this project with Unity 2019.3.0f6 and wait for compilation.
echo Menu: Island2019 / 1 - Build Assets and Gallery
echo Menu: Island2019 / 2 - Build Island Combat Scene
echo Play the gallery. Press 0/1/2/3/4 for asset views and F8 for screenshots.
echo Screenshots are saved in the project folder / Screenshots.
echo This installation does not change your original clean island scene.
echo Unity 2019 Play Mode still needs local verification.
pause
exit /b 0
:alreadyInstalled
echo The IslandQuest2019 folder already exists. No existing files were overwritten.
echo Open Unity and use the Island2019 build menus. Back up your edits before updating.
goto stop
:missingPatch
echo ERROR - Extract the whole ZIP first. The Assets folder must be beside this CMD.
goto stop
:wrongProject
echo ERROR - Select the prepared Unity 2019.3.0f6 clean island project.
goto stop
:failed
echo ERROR - Verification or copying failed. Send a screenshot of this window.
:stop
pause
exit /b 1
