@echo off
setlocal EnableExtensions DisableDelayedExpansion
title BoatAttack - Copy and adapt the existing project for Unity 2019
echo Copy-and-adapt patch for Unity 2019.3.0f6.
echo Close Unity before running this tool. Run normally; no administrator rights needed.
echo The source project is preserved. Only the new copy receives replacements.
echo This tool uses local files only; it does not download from GitHub.
echo.
set "patchPath=%~dp0Overlay"
if not exist "%patchPath%\Packages\manifest.json" goto missingPatch
set "sourcePath=D:\github-Unity2020-28206-10141"
if exist "%sourcePath%\ProjectSettings\ProjectVersion.txt" goto sourceReady
echo Paste your existing Unity 2020 project folder, without surrounding quotes.
set /p "sourcePath=Source project folder: "
:sourceReady
if not exist "%sourcePath%\Assets" goto missingSource
if not exist "%sourcePath%\Packages\com.verasl.water-system" goto missingSource
if not exist "%sourcePath%\ProjectSettings\ProjectVersion.txt" goto missingSource
set "sourceVersionOK="
for /f "usebackq tokens=1,2" %%A in ("%sourcePath%\ProjectSettings\ProjectVersion.txt") do if "%%A"=="m_EditorVersion:" if "%%B"=="2020.3.23f1" set "sourceVersionOK=1"
if not defined sourceVersionOK goto badSourceVersion
set "outputParent=%USERPROFILE%\Downloads"
if exist "D:\" set "outputParent=D:"
set "targetPath=%outputParent%\BoatAttack-2019-From2020-%RANDOM%-%RANDOM%"
set "zipPath=%targetPath%.zip"
if exist "%targetPath%" goto collision
if exist "%zipPath%" goto collision
echo Source: "%sourcePath%"
echo New copy: "%targetPath%"
echo ZIP: "%zipPath%"
echo.
echo Step 1: Copying existing models, textures, materials and environment prefabs...
rem Omit 2020-only logic, Shader Graph data, old baked scenes and generated state.
rem Their 2019 replacements are provided in Overlay; no source file is removed.
robocopy "%sourcePath%\Assets" "%targetPath%\Assets" /E /R:1 /W:1 /XD "%sourcePath%\Assets\Scripts" "%sourcePath%\Assets\Shaders" "%sourcePath%\Assets\Tidebound" "%sourcePath%\Assets\scenes" "%sourcePath%\Assets\NavMeshComponents" "%sourcePath%\Assets\Data\UniversalRP" "%sourcePath%\Assets\Data\Volumes" /XF *.lighting *.lighting.meta UniversalRenderPipelineGlobalSettings.asset UniversalRenderPipelineGlobalSettings.asset.meta /NFL /NDL /NJH /NJS
if errorlevel 8 goto failed
robocopy "%sourcePath%\Packages\com.verasl.water-system" "%targetPath%\Packages\com.verasl.water-system" /E /R:1 /W:1 /NFL /NDL /NJH /NJS
if errorlevel 8 goto failed
echo Step 2: Applying 2019 scripts, shaders, water system, terrain and settings...
robocopy "%patchPath%" "%targetPath%" /E /R:1 /W:1 /NFL /NDL /NJH /NJS
if errorlevel 8 goto failed
rem Preserve the layer names used by the copied 2020 environment and skybox.
copy /Y "%sourcePath%\ProjectSettings\TagManager.asset" "%targetPath%\ProjectSettings\TagManager.asset" >nul
if errorlevel 1 goto failed
if not exist "%targetPath%\Assets\scenes\island_clean_2019.unity" goto failed
if not exist "%targetPath%\Packages\net.peeweek.gameplay-ingredients\package.json" goto failed
set "ISLAND2019_PATH=%targetPath%"
set "ISLAND2019_ZIP=%zipPath%"
echo Step 3: Verifying local files and creating the ZIP. This can take a few minutes...
powershell.exe -NoProfile -Command "$ErrorActionPreference='Stop'; $root=$env:ISLAND2019_PATH; Get-ChildItem -LiteralPath $root -Recurse -File | Where-Object { $_.Extension -in '.fbx','.tif','.png','.exr','.tga' -and $_.Length -lt 1024 } | ForEach-Object { if ((Get-Content -LiteralPath $_.FullName -TotalCount 1) -eq 'version https://git-lfs.github.com/spec/v1') { throw ('Missing source LFS asset: '+$_.FullName) } }; $version=Get-Content -LiteralPath (Join-Path $root 'ProjectSettings\ProjectVersion.txt'); if ($version -notcontains 'm_EditorVersion: 2019.3.0f6') { throw 'Unexpected target version' }; $items=@('Assets','Packages','ProjectSettings','COMPAT2019.md','LICENSE.md') | ForEach-Object { Join-Path $root $_ }; Compress-Archive -LiteralPath $items -DestinationPath $env:ISLAND2019_ZIP -CompressionLevel Optimal"
if errorlevel 1 goto failed
if not exist "%zipPath%" goto failed
echo.
echo DONE - A Unity 2019 candidate copy and ZIP were prepared from local assets.
echo Send this ZIP to your classmate:
echo "%zipPath%"
echo Use Unity 2019.3.0f6, then Island2019 / Open Clean Island.
echo First import may download Unity registry packages. No Git dependency is needed.
echo Actual Unity 2019 import and rendering still need verification.
pause
exit /b 0
:missingPatch
echo ERROR - Extract the WHOLE patch ZIP first. Overlay must be beside this CMD.
goto stop
:missingSource
echo ERROR - Source folder is not the expected BoatAttack project.
goto stop
:badSourceVersion
echo ERROR - This patch targets the known Unity 2020.3.23f1 project.
type "%sourcePath%\ProjectSettings\ProjectVersion.txt"
goto stop
:collision
echo ERROR - Generated output already exists. Run again to choose a new folder name.
goto stop
:failed
echo ERROR - Conversion or ZIP creation stopped. Do not share the incomplete copy.
echo Source project was preserved. Send a screenshot of this window.
:stop
pause
exit /b 1
