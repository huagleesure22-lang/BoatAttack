// GENERATED AUTOMATICALLY FROM 'Assets/Data/InputControls.inputactions'

using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Utilities;

public class @InputControls : IInputActionCollection, IDisposable
{
    public InputActionAsset asset { get; }
    public @InputControls()
    {
        asset = InputActionAsset.FromJson(@"{
    ""name"": ""InputControls"",
    ""maps"": [
        {
            ""name"": ""BoatControls"",
            ""id"": ""ef127e39-c6d2-4d6f-8edc-46296d5de0cb"",
            ""actions"": [
                {
                    ""name"": ""Trottle"",
                    ""type"": ""Value"",
                    ""id"": ""591093b7-743c-42e6-b71e-bab02d178bd1"",
                    ""expectedControlType"": ""Axis"",
                    ""processors"": ""AxisDeadzone(min=0.1,max=1)"",
                    ""interactions"": """"
                },
                {
                    ""name"": ""Time"",
                    ""type"": ""Value"",
                    ""id"": ""637a3778-b50e-41a0-8669-f7b1698fc4ca"",
                    ""expectedControlType"": """",
                    ""processors"": ""AxisDeadzone(min=0.1,max=1)"",
                    ""interactions"": """"
                },
                {
                    ""name"": ""Steering"",
                    ""type"": ""Value"",
                    ""id"": ""67e3403a-b3e8-43af-ab52-4575ba23afef"",
                    ""expectedControlType"": ""Axis"",
                    ""processors"": ""AxisDeadzone(min=0.1,max=1)"",
                    ""interactions"": """"
                },
                {
                    ""name"": ""Reset"",
                    ""type"": ""Button"",
                    ""id"": ""218640d2-e6dc-4136-842e-4621c0883e15"",
                    ""expectedControlType"": """",
                    ""processors"": ""AxisDeadzone(min=0.1,max=1)"",
                    ""interactions"": """"
                },
                {
                    ""name"": ""Freeze"",
                    ""type"": ""Button"",
                    ""id"": ""097a2ec8-8df3-4d48-96e5-fbf096270878"",
                    ""expectedControlType"": """",
                    ""processors"": ""AxisDeadzone(min=0.1,max=1)"",
                    ""interactions"": """"
                }
            ],
            ""bindings"": [
                {
                    ""name"": ""Triggers"",
                    ""id"": ""3466fe24-0064-418d-9331-557be3fdcac4"",
                    ""path"": ""1DAxis"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": """",
                    ""action"": ""Trottle"",
                    ""isComposite"": true,
                    ""isPartOfComposite"": false
                },
                {
                    ""name"": ""negative"",
                    ""id"": ""eff0cde8-c5f9-43b6-86e8-8385017c8985"",
                    ""path"": ""<Gamepad>/leftTrigger"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": ""Gamepad"",
                    ""action"": ""Trottle"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": true
                },
                {
                    ""name"": ""positive"",
                    ""id"": ""e7382d1c-3b18-4582-9511-5569c858581e"",
                    ""path"": ""<Gamepad>/rightTrigger"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": ""Gamepad"",
                    ""action"": ""Trottle"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": true
                },
                {
                    ""name"": ""Buttons"",
                    ""id"": ""e1093b33-e798-4080-866e-f94010a4d7e0"",
                    ""path"": ""1DAxis"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": """",
                    ""action"": ""Trottle"",
                    ""isComposite"": true,
                    ""isPartOfComposite"": false
                },
                {
                    ""name"": ""negative"",
                    ""id"": ""b9957a1f-893b-4ee8-9579-667c3bb073d3"",
                    ""path"": ""<Gamepad>/buttonEast"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": "";Gamepad"",
                    ""action"": ""Trottle"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": true
                },
                {
                    ""name"": ""positive"",
                    ""id"": ""de45f7f3-08ae-4508-a9d8-aca8191f35a1"",
                    ""path"": ""<Gamepad>/buttonSouth"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": "";Gamepad"",
                    ""action"": ""Trottle"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": true
                },
                {
                    ""name"": ""Arrows"",
                    ""id"": ""4caeca52-a08d-469a-a986-778564c27c84"",
                    ""path"": ""1DAxis"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": """",
                    ""action"": ""Trottle"",
                    ""isComposite"": true,
                    ""isPartOfComposite"": false
                },
                {
                    ""name"": ""negative"",
                    ""id"": ""6b1d89c6-a8e7-4b32-9c05-f848bb1064a8"",
                    ""path"": ""<Keyboard>/downArrow"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": ""Keyboard"",
                    ""action"": ""Trottle"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": true
                },
                {
                    ""name"": ""positive"",
                    ""id"": ""b25a71de-239c-4d0a-8050-0169566cea38"",
                    ""path"": ""<Keyboard>/upArrow"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": ""Keyboard"",
                    ""action"": ""Trottle"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": true
                },
                {
                    ""name"": ""WSAD"",
                    ""id"": ""1d540095-a749-43de-89cd-2806255106e3"",
                    ""path"": ""1DAxis"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": """",
                    ""action"": ""Trottle"",
                    ""isComposite"": true,
                    ""isPartOfComposite"": false
                },
                {
                    ""name"": ""negative"",
                    ""id"": ""c59fc22d-e257-4273-9159-4416a56a15d0"",
                    ""path"": ""<Keyboard>/s"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": ""Keyboard"",
                    ""action"": ""Trottle"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": true
                },
                {
                    ""name"": ""positive"",
                    ""id"": ""a91b562c-2ac5-4d79-9a5b-1f2e59241e92"",
                    ""path"": ""<Keyboard>/w"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": ""Keyboard"",
                    ""action"": ""Trottle"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": true
                },
                {
                    ""name"": ""Alt"",
                    ""id"": ""edd450a3-5814-4902-80ec-bcc25edd0366"",
                    ""path"": ""1DAxis"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": """",
                    ""action"": ""Trottle"",
                    ""isComposite"": true,
                    ""isPartOfComposite"": false
                },
                {
                    ""name"": ""negative"",
                    ""id"": ""71ae2e67-e9b6-4a48-9669-38e7fe243cbc"",
                    ""path"": ""<Keyboard>/z"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": ""Keyboard"",
                    ""action"": ""Trottle"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": true
                },
                {
                    ""name"": ""positive"",
                    ""id"": ""a1291229-823b-4ede-82e6-090bc1bdfa21"",
                    ""path"": ""<Keyboard>/space"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": ""Keyboard"",
                    ""action"": ""Trottle"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": true
                },
                {
                    ""name"": """",
                    ""id"": ""30ce0b9b-3da0-420a-abc3-8f2040388953"",
                    ""path"": ""<Touchscreen>/touch/position/y"",
                    ""interactions"": """",
                    ""processors"": ""Clamp(min=-1,max=1)"",
                    ""groups"": ""TouchScreen"",
                    ""action"": ""Trottle"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": false
                },
                {
                    ""name"": ""LeftThumbstick"",
                    ""id"": ""01df8425-ce9a-4024-bad4-0f5e8002094f"",
                    ""path"": ""1DAxis"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": """",
                    ""action"": ""Steering"",
                    ""isComposite"": true,
                    ""isPartOfComposite"": false
                },
                {
                    ""name"": ""negative"",
                    ""id"": ""3866264b-46e4-428b-9624-ada67f2de7bd"",
                    ""path"": ""<Gamepad>/leftStick/left"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": ""Gamepad"",
                    ""action"": ""Steering"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": true
                },
                {
                    ""name"": ""positive"",
                    ""id"": ""9a637b8c-8d48-42f2-9cef-114e3b8bb2ba"",
                    ""path"": ""<Gamepad>/leftStick/right"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": ""Gamepad"",
                    ""action"": ""Steering"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": true
                },
                {
                    ""name"": ""Arrows"",
                    ""id"": ""b5b408fa-df11-4ebc-b589-5ff03be94ba1"",
                    ""path"": ""1DAxis"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": """",
                    ""action"": ""Steering"",
                    ""isComposite"": true,
                    ""isPartOfComposite"": false
                },
                {
                    ""name"": ""negative"",
                    ""id"": ""010e7196-f4dd-4d5c-8f42-f47f3984bc01"",
                    ""path"": ""<Keyboard>/leftArrow"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": ""Keyboard"",
                    ""action"": ""Steering"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": true
                },
                {
                    ""name"": ""positive"",
                    ""id"": ""36de1a52-c485-4d40-8d4d-323d8fe73445"",
                    ""path"": ""<Keyboard>/rightArrow"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": ""Keyboard"",
                    ""action"": ""Steering"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": true
                },
                {
                    ""name"": ""WSAD"",
                    ""id"": ""24d9ae40-f8f8-4a39-abbe-68ce064083f8"",
                    ""path"": ""1DAxis"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": """",
                    ""action"": ""Steering"",
                    ""isComposite"": true,
                    ""isPartOfComposite"": false
                },
                {
                    ""name"": ""negative"",
                    ""id"": ""c07695cd-a24b-4ba5-8162-fd6c1d55667a"",
                    ""path"": ""<Keyboard>/a"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": ""Keyboard"",
                    ""action"": ""Steering"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": true
                },
                {
                    ""name"": ""positive"",
                    ""id"": ""72970fc1-f5b9-4e7b-bfb0-8356935a6274"",
                    ""path"": ""<Keyboard>/d"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": ""Keyboard"",
                    ""action"": ""Steering"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": true
                },
                {
                    ""name"": """",
                    ""id"": ""3d3dbb25-9147-4e77-ae9d-04d1c01d2666"",
                    ""path"": ""<Touchscreen>/tilt/x"",
                    ""interactions"": """",
                    ""processors"": ""Clamp(min=-1,max=1)"",
                    ""groups"": ""TouchScreen"",
                    ""action"": ""Steering"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": false
                },
                {
                    ""name"": """",
                    ""id"": ""7a7ffffc-09c1-403a-b879-7a91dfb5b29d"",
                    ""path"": ""<Gamepad>/select"",
                    ""interactions"": ""Press"",
                    ""processors"": """",
                    ""groups"": ""Gamepad"",
                    ""action"": ""Reset"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": false
                },
                {
                    ""name"": """",
                    ""id"": ""b449cb97-f7cf-448b-9aa9-900c8085c53d"",
                    ""path"": ""<Keyboard>/#(r)"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": ""Keyboard"",
                    ""action"": ""Reset"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": false
                },
                {
                    ""name"": """",
                    ""id"": ""f8b1e58a-fd18-487f-ae58-dc92e5273625"",
                    ""path"": ""<Touchscreen>/primaryTouch/tapCount"",
                    ""interactions"": ""MultiTap(tapCount=3)"",
                    ""processors"": """",
                    ""groups"": ""TouchScreen"",
                    ""action"": ""Reset"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": false
                },
                {
                    ""name"": """",
                    ""id"": ""bbe374df-c0a2-4067-8743-605cc47e112b"",
                    ""path"": ""<Gamepad>/start"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": ""Gamepad"",
                    ""action"": ""Freeze"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": false
                },
                {
                    ""name"": """",
                    ""id"": ""6c9efbd8-b12e-4a6d-9787-042b4abda799"",
                    ""path"": ""<Keyboard>/f"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": ""Keyboard"",
                    ""action"": ""Freeze"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": false
                },
                {
                    ""name"": """",
                    ""id"": ""b7d3341c-7abe-48e6-a68e-b27eb3927b79"",
                    ""path"": ""<Gamepad>/buttonNorth"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": ""Gamepad"",
                    ""action"": ""Time"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": false
                },
                {
                    ""name"": ""Dpad horizontal"",
                    ""id"": ""3c94f068-2cc6-4d07-a76a-3835151e0b0e"",
                    ""path"": ""1DAxis"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": """",
                    ""action"": ""Time"",
                    ""isComposite"": true,
                    ""isPartOfComposite"": false
                },
                {
                    ""name"": ""negative"",
                    ""id"": ""aa687506-3f38-4cdc-8f14-f77ce23789d9"",
                    ""path"": ""<Gamepad>/dpad/left"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": ""Gamepad"",
                    ""action"": ""Time"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": true
                },
                {
                    ""name"": ""positive"",
                    ""id"": ""59cadf6b-f60d-4a7e-9b9c-a21ecfdfb51e"",
                    ""path"": ""<Gamepad>/dpad/right"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": ""Gamepad"",
                    ""action"": ""Time"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": true
                },
                {
                    ""name"": ""Keyboard"",
                    ""id"": ""e8db53d1-5ded-40fe-965b-727f321a403a"",
                    ""path"": ""1DAxis"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": """",
                    ""action"": ""Time"",
                    ""isComposite"": true,
                    ""isPartOfComposite"": false
                },
                {
                    ""name"": ""negative"",
                    ""id"": ""d5357c68-6b8a-4c12-996c-801c5a015beb"",
                    ""path"": ""<Keyboard>/1"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": ""Keyboard"",
                    ""action"": ""Time"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": true
                },
                {
                    ""name"": ""positive"",
                    ""id"": ""9a495693-8098-4d83-b2d6-711526e83c37"",
                    ""path"": ""<Keyboard>/2"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": ""Keyboard"",
                    ""action"": ""Time"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": true
                },
                {
                    ""name"": """",
                    ""id"": ""38dc845f-f219-4b56-947c-542a4cf33da6"",
                    ""path"": ""<Touchscreen>/primaryTouch/tapCount"",
                    ""interactions"": ""MultiTap"",
                    ""processors"": """",
                    ""groups"": ""TouchScreen"",
                    ""action"": ""Time"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": false
                }
            ]
        }
    ],
    ""controlSchemes"": [
        {
            ""name"": ""Gamepad"",
            ""bindingGroup"": ""Gamepad"",
            ""devices"": [
                {
                    ""devicePath"": ""<Gamepad>"",
                    ""isOptional"": false,
                    ""isOR"": false
                },
                {
                    ""devicePath"": ""<SwitchProControllerHID>"",
                    ""isOptional"": true,
                    ""isOR"": false
                }
            ]
        },
        {
            ""name"": ""Keyboard"",
            ""bindingGroup"": ""Keyboard"",
            ""devices"": [
                {
                    ""devicePath"": ""<Keyboard>"",
                    ""isOptional"": false,
                    ""isOR"": false
                }
            ]
        },
        {
            ""name"": ""TouchScreen"",
            ""bindingGroup"": ""TouchScreen"",
            ""devices"": [
                {
                    ""devicePath"": ""<Touchscreen>"",
                    ""isOptional"": false,
                    ""isOR"": false
                }
            ]
        }
    ]
}");
        // BoatControls
        m_BoatControls = asset.FindActionMap("BoatControls", throwIfNotFound: true);
        m_BoatControls_Trottle = m_BoatControls.FindAction("Trottle", throwIfNotFound: true);
        m_BoatControls_Time = m_BoatControls.FindAction("Time", throwIfNotFound: true);
        m_BoatControls_Steering = m_BoatControls.FindAction("Steering", throwIfNotFound: true);
        m_BoatControls_Reset = m_BoatControls.FindAction("Reset", throwIfNotFound: true);
        m_BoatControls_Freeze = m_BoatControls.FindAction("Freeze", throwIfNotFound: true);
    }

    public void Dispose()
    {
        UnityEngine.Object.Destroy(asset);
    }

    public InputBinding? bindingMask
    {
        get => asset.bindingMask;
        set => asset.bindingMask = value;
    }

    public ReadOnlyArray<InputDevice>? devices
    {
        get => asset.devices;
        set => asset.devices = value;
    }

    public ReadOnlyArray<InputControlScheme> controlSchemes => asset.controlSchemes;

    public bool Contains(InputAction action)
    {
        return asset.Contains(action);
    }

    public IEnumerator<InputAction> GetEnumerator()
    {
        return asset.GetEnumerator();
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
        return GetEnumerator();
    }

    public void Enable()
    {
        asset.Enable();
    }

    public void Disable()
    {
        asset.Disable();
    }

    // BoatControls
    private readonly InputActionMap m_BoatControls;
    private IBoatControlsActions m_BoatControlsActionsCallbackInterface;
    private readonly InputAction m_BoatControls_Trottle;
    private readonly InputAction m_BoatControls_Time;
    private readonly InputAction m_BoatControls_Steering;
    private readonly InputAction m_BoatControls_Reset;
    private readonly InputAction m_BoatControls_Freeze;
    public struct BoatControlsActions
    {
        private @InputControls m_Wrapper;
        public BoatControlsActions(@InputControls wrapper) { m_Wrapper = wrapper; }
        public InputAction @Trottle => m_Wrapper.m_BoatControls_Trottle;
        public InputAction @Time => m_Wrapper.m_BoatControls_Time;
        public InputAction @Steering => m_Wrapper.m_BoatControls_Steering;
        public InputAction @Reset => m_Wrapper.m_BoatControls_Reset;
        public InputAction @Freeze => m_Wrapper.m_BoatControls_Freeze;
        public InputActionMap Get() { return m_Wrapper.m_BoatControls; }
        public void Enable() { Get().Enable(); }
        public void Disable() { Get().Disable(); }
        public bool enabled => Get().enabled;
        public static implicit operator InputActionMap(BoatControlsActions set) { return set.Get(); }
        public void SetCallbacks(IBoatControlsActions instance)
        {
            if (m_Wrapper.m_BoatControlsActionsCallbackInterface != null)
            {
                @Trottle.started -= m_Wrapper.m_BoatControlsActionsCallbackInterface.OnTrottle;
                @Trottle.performed -= m_Wrapper.m_BoatControlsActionsCallbackInterface.OnTrottle;
                @Trottle.canceled -= m_Wrapper.m_BoatControlsActionsCallbackInterface.OnTrottle;
                @Time.started -= m_Wrapper.m_BoatControlsActionsCallbackInterface.OnTime;
                @Time.performed -= m_Wrapper.m_BoatControlsActionsCallbackInterface.OnTime;
                @Time.canceled -= m_Wrapper.m_BoatControlsActionsCallbackInterface.OnTime;
                @Steering.started -= m_Wrapper.m_BoatControlsActionsCallbackInterface.OnSteering;
                @Steering.performed -= m_Wrapper.m_BoatControlsActionsCallbackInterface.OnSteering;
                @Steering.canceled -= m_Wrapper.m_BoatControlsActionsCallbackInterface.OnSteering;
                @Reset.started -= m_Wrapper.m_BoatControlsActionsCallbackInterface.OnReset;
                @Reset.performed -= m_Wrapper.m_BoatControlsActionsCallbackInterface.OnReset;
                @Reset.canceled -= m_Wrapper.m_BoatControlsActionsCallbackInterface.OnReset;
                @Freeze.started -= m_Wrapper.m_BoatControlsActionsCallbackInterface.OnFreeze;
                @Freeze.performed -= m_Wrapper.m_BoatControlsActionsCallbackInterface.OnFreeze;
                @Freeze.canceled -= m_Wrapper.m_BoatControlsActionsCallbackInterface.OnFreeze;
            }
            m_Wrapper.m_BoatControlsActionsCallbackInterface = instance;
            if (instance != null)
            {
                @Trottle.started += instance.OnTrottle;
                @Trottle.performed += instance.OnTrottle;
                @Trottle.canceled += instance.OnTrottle;
                @Time.started += instance.OnTime;
                @Time.performed += instance.OnTime;
                @Time.canceled += instance.OnTime;
                @Steering.started += instance.OnSteering;
                @Steering.performed += instance.OnSteering;
                @Steering.canceled += instance.OnSteering;
                @Reset.started += instance.OnReset;
                @Reset.performed += instance.OnReset;
                @Reset.canceled += instance.OnReset;
                @Freeze.started += instance.OnFreeze;
                @Freeze.performed += instance.OnFreeze;
                @Freeze.canceled += instance.OnFreeze;
            }
        }
    }
    public BoatControlsActions @BoatControls => new BoatControlsActions(this);
    private int m_GamepadSchemeIndex = -1;
    public InputControlScheme GamepadScheme
    {
        get
        {
            if (m_GamepadSchemeIndex == -1) m_GamepadSchemeIndex = asset.FindControlSchemeIndex("Gamepad");
            return asset.controlSchemes[m_GamepadSchemeIndex];
        }
    }
    private int m_KeyboardSchemeIndex = -1;
    public InputControlScheme KeyboardScheme
    {
        get
        {
            if (m_KeyboardSchemeIndex == -1) m_KeyboardSchemeIndex = asset.FindControlSchemeIndex("Keyboard");
            return asset.controlSchemes[m_KeyboardSchemeIndex];
        }
    }
    private int m_TouchScreenSchemeIndex = -1;
    public InputControlScheme TouchScreenScheme
    {
        get
        {
            if (m_TouchScreenSchemeIndex == -1) m_TouchScreenSchemeIndex = asset.FindControlSchemeIndex("TouchScreen");
            return asset.controlSchemes[m_TouchScreenSchemeIndex];
        }
    }
    public interface IBoatControlsActions
    {
        void OnTrottle(InputAction.CallbackContext context);
        void OnTime(InputAction.CallbackContext context);
        void OnSteering(InputAction.CallbackContext context);
        void OnReset(InputAction.CallbackContext context);
        void OnFreeze(InputAction.CallbackContext context);
    }
}
